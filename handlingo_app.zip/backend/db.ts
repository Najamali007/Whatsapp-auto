import knex from 'knex';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let isMySQL = !!(process.env.DB_HOST && process.env.DB_USER && process.env.DB_NAME);

const mysqlConfig = {
  client: 'mysql2',
  connection: {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: parseInt(process.env.DB_PORT || '3306'),
  },
  pool: { min: 0, max: 10 }
};

const sqliteConfig = {
  client: 'better-sqlite3',
  connection: {
    // AWS pe /data volume mount karo — warna process.cwd() use hoga
    filename: process.env.DB_PATH || path.join(process.cwd(), 'database.sqlite'),
  },
  useNullAsDefault: true
};

let currentDb = knex(isMySQL ? mysqlConfig : sqliteConfig);

// Proxy to allow dynamic switching of the knex instance
const dbProxy = new Proxy(() => {}, {
  get(_, prop) {
    return (currentDb as any)[prop];
  },
  apply(_, thisArg, argArray) {
    return (currentDb as any)(...argArray);
  }
}) as any;

// Initialize tables
async function initDb() {
  if (isMySQL) {
    try {
      console.log('Attempting to connect to MySQL...');
      // Try a simple query with a short timeout to check connection
      await Promise.race([
        currentDb.raw('SELECT 1'),
        new Promise((_, reject) => setTimeout(() => reject(new Error('MySQL connection timeout')), 5000))
      ]);
      console.log('Connected to MySQL successfully');
    } catch (error: any) {
      console.error('MySQL connection failed, falling back to SQLite:', error.message);
      isMySQL = false;
      // Close the failed MySQL connection pool if possible
      try { await currentDb.destroy(); } catch (e) {}
      currentDb = knex(sqliteConfig);
    }
  }

  const hasUsers = await dbProxy.schema.hasTable('users');
  if (!hasUsers) {
    await dbProxy.schema.createTable('users', (table) => {
      table.increments('id').primary();
      table.string('username').unique().notNullable();
      table.string('password').notNullable();
      table.string('name').nullable();
      table.string('avatar').nullable();
      table.string('role').defaultTo('admin'); // 'super_admin' or 'admin'
      table.integer('is_active').defaultTo(1);
      table.string('security_key').nullable();
      table.integer('is_global_autopilot').defaultTo(1);
      table.integer('tokens').defaultTo(0);
      table.integer('token_limit').defaultTo(0);
      table.integer('is_tracking_active').defaultTo(0);
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  } else {
    // Migration for existing table
    const hasRole = await dbProxy.schema.hasColumn('users', 'role');
    if (!hasRole) {
      await dbProxy.schema.table('users', (table) => {
        table.string('role').defaultTo('admin');
      });
    }
    const hasName = await dbProxy.schema.hasColumn('users', 'name');
    if (!hasName) {
      await dbProxy.schema.table('users', (table) => {
        table.string('name').nullable();
      });
    }
    const hasAvatar = await dbProxy.schema.hasColumn('users', 'avatar');
    if (!hasAvatar) {
      await dbProxy.schema.table('users', (table) => {
        table.string('avatar').nullable();
      });
    }
    const hasIsActive = await dbProxy.schema.hasColumn('users', 'is_active');
    if (!hasIsActive) {
      await dbProxy.schema.table('users', (table) => {
        table.integer('is_active').defaultTo(1);
      });
    }
    const hasSecurityKey = await dbProxy.schema.hasColumn('users', 'security_key');
    if (!hasSecurityKey) {
      await dbProxy.schema.table('users', (table) => {
        table.string('security_key').nullable();
      });
    }
    const hasTokens = await dbProxy.schema.hasColumn('users', 'tokens');
    if (!hasTokens) {
      await dbProxy.schema.table('users', (table) => {
        table.integer('tokens').defaultTo(0);
        table.integer('token_limit').defaultTo(0);
      });
    }
    const hasIsTrackingActive = await dbProxy.schema.hasColumn('users', 'is_tracking_active');
    if (!hasIsTrackingActive) {
      await dbProxy.schema.table('users', (table) => {
        table.integer('is_tracking_active').defaultTo(0);
      });
    }
    // Email + 2FA migration
    const hasEmail = await dbProxy.schema.hasColumn('users', 'email');
    if (!hasEmail) {
      await dbProxy.schema.table('users', (table) => {
        table.string('email').nullable();
        table.integer('two_fa_enabled').defaultTo(0);
      });
    }
  }

  // Payment requests table
  const hasPaymentRequests = await dbProxy.schema.hasTable('payment_requests');
  if (!hasPaymentRequests) {
    await dbProxy.schema.createTable('payment_requests', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.integer('tokens_requested').notNullable();
      table.float('amount_usd').notNullable();
      table.string('package_label').nullable(); // '500', '1000', '2000', 'custom'
      table.string('screenshot_path').nullable();
      table.string('status').defaultTo('pending'); // pending, approved, rejected
      table.string('bank_name').nullable();
      table.string('account_number').nullable();
      table.text('admin_note').nullable();
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
      table.timestamp('updated_at').defaultTo(dbProxy.fn.now());
    });
  }

  // Token transaction log
  const hasTokenLogs = await dbProxy.schema.hasTable('token_logs');
  if (!hasTokenLogs) {
    await dbProxy.schema.createTable('token_logs', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.integer('tokens').notNullable();
      table.string('type').defaultTo('topup'); // topup, deduct
      table.string('description').nullable();
      table.integer('payment_request_id').nullable();
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  }

  // Insert default super admin if not exists
  const superAdminUsername = 'najam786ali@yahoo.com';
  const superAdminPassword = 'Password';
  const superAdminKey = 'Najam2712ali';
  
  const superAdmin = await dbProxy('users').where({ username: superAdminUsername }).first();
  if (!superAdmin) {
    const hashedPassword = bcrypt.hashSync(superAdminPassword, 10);
    await dbProxy('users').insert({
      username: superAdminUsername,
      password: hashedPassword,
      role: 'super_admin',
      security_key: superAdminKey,
      is_active: 1,
      is_global_autopilot: 1
    });
    console.log('Super admin created: ' + superAdminUsername);
  }

  // Remove old legacy admin if it exists
  await dbProxy('users').where({ username: 'ondigixsolutions@gmail.com' }).delete();

  const hasAgents = await dbProxy.schema.hasTable('agents');
  if (!hasAgents) {
    await dbProxy.schema.createTable('agents', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.string('name').notNullable();
      table.text('personality');
      table.text('role');
      table.text('knowledge_base');
      table.text('brand_company');
      table.text('product_service');
      table.text('objective');
      table.text('tone');
      table.text('playbook');
      table.text('others');
      table.text('avatar');
      table.text('strategy');
      table.text('agent_config'); // JSON: services, greeting, fallback, pricing rules
      table.integer('is_active').defaultTo(1);
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  } else {
    const hasAgentConfig = await dbProxy.schema.hasColumn('agents', 'agent_config');
    if (!hasAgentConfig) {
      await dbProxy.schema.table('agents', (table) => {
        table.text('agent_config').nullable();
      });
    }
  }

  const hasSessions = await dbProxy.schema.hasTable('whatsapp_sessions');
  if (!hasSessions) {
    await dbProxy.schema.createTable('whatsapp_sessions', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.integer('agent_id').unsigned().references('id').inTable('agents').onDelete('CASCADE');
      table.string('name');
      table.string('number').unique();
      table.string('status').defaultTo('disconnected');
      table.string('platform').defaultTo('whatsapp'); // 'whatsapp', 'facebook', 'instagram'
      table.text('session_data');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  } else {
    const hasPlatform = await dbProxy.schema.hasColumn('whatsapp_sessions', 'platform');
    if (!hasPlatform) {
      await dbProxy.schema.table('whatsapp_sessions', (table) => {
        table.string('platform').defaultTo('whatsapp');
      });
    }
    const hasProfileName = await dbProxy.schema.hasColumn('whatsapp_sessions', 'profile_name');
    if (!hasProfileName) {
      await dbProxy.schema.table('whatsapp_sessions', (table) => {
        table.string('profile_name').nullable();
      });
    }
  }

  // Agent memory table — permanent training chat history
  const hasAgentMemory = await dbProxy.schema.hasTable('agent_memory');
  if (!hasAgentMemory) {
    await dbProxy.schema.createTable('agent_memory', (table) => {
      table.increments('id').primary();
      table.integer('agent_id').unsigned().references('id').inTable('agents').onDelete('CASCADE');
      table.string('topic').notNullable();
      table.text('content').notNullable();
      table.text('prev_content').nullable(); // Archive of previous version
      table.string('source').defaultTo('chat');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
      table.timestamp('updated_at').defaultTo(dbProxy.fn.now());
    });
  } else {
    const hasPrevContent = await dbProxy.schema.hasColumn('agent_memory', 'prev_content');
    if (!hasPrevContent) {
      await dbProxy.schema.table('agent_memory', (table) => {
        table.text('prev_content').nullable();
      });
    }
  }

  // Agent training chat sessions
  const hasAgentTrainingChats = await dbProxy.schema.hasTable('agent_training_chats');
  if (!hasAgentTrainingChats) {
    await dbProxy.schema.createTable('agent_training_chats', (table) => {
      table.increments('id').primary();
      table.integer('agent_id').unsigned().references('id').inTable('agents').onDelete('CASCADE');
      table.string('role').notNullable(); // 'user' or 'agent'
      table.text('content').notNullable();
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  }

  const hasConversations = await dbProxy.schema.hasTable('conversations');
  if (!hasConversations) {
    await dbProxy.schema.createTable('conversations', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('SET NULL');
      table.integer('session_id').unsigned().references('id').inTable('whatsapp_sessions').onDelete('SET NULL');
      table.string('contact_number').notNullable();
      table.string('contact_name');
      table.string('platform').defaultTo('whatsapp');
      table.string('audit_status').defaultTo('none'); // 'none', 'added', 'audited'
      table.integer('unread_count').defaultTo(0);
      table.integer('is_saved').defaultTo(0);
      table.integer('is_ordered').defaultTo(0);
      table.integer('is_rated').defaultTo(0);
      table.integer('is_audited').defaultTo(0);
      table.integer('is_autopilot').defaultTo(1);
      table.string('intent');
      table.float('engagement_score').defaultTo(0);
      table.string('objective').defaultTo('Collect contact information');
      table.integer('objective_progress').defaultTo(0); // 0: Not Started, 50: In Progress, 100: Completed
      table.text('labels'); // JSON array of labels
      table.timestamp('last_reminder_sent_at');
      table.timestamp('last_greeting_at');
      table.timestamp('last_message_at').defaultTo(dbProxy.fn.now());
    });
  } else {
    // Add objective fields if they don't exist (for existing DBs)
    const hasObjective = await dbProxy.schema.hasColumn('conversations', 'objective');
    if (!hasObjective) {
      await dbProxy.schema.table('conversations', (table) => {
        table.string('objective').defaultTo('Collect contact information');
        table.integer('objective_progress').defaultTo(0);
      });
    }
    const hasGreetingAt = await dbProxy.schema.hasColumn('conversations', 'last_greeting_at');
    if (!hasGreetingAt) {
      await dbProxy.schema.table('conversations', (table) => {
        table.timestamp('last_greeting_at');
      });
    }
    const hasAgentMessageAt = await dbProxy.schema.hasColumn('conversations', 'last_agent_message_at');
    if (!hasAgentMessageAt) {
      await dbProxy.schema.table('conversations', (table) => {
        table.timestamp('last_agent_message_at');
      });
    }
    const hasLabels = await dbProxy.schema.hasColumn('conversations', 'labels');
    if (!hasLabels) {
      await dbProxy.schema.table('conversations', (table) => {
        table.text('labels');
      });
    }
    const hasPlatform = await dbProxy.schema.hasColumn('conversations', 'platform');
    if (!hasPlatform) {
      await dbProxy.schema.table('conversations', (table) => {
        table.string('platform').defaultTo('whatsapp');
      });
    }
    const hasAuditStatus = await dbProxy.schema.hasColumn('conversations', 'audit_status');
    if (!hasAuditStatus) {
      await dbProxy.schema.table('conversations', (table) => {
        table.string('audit_status').defaultTo('none');
      });
    }
    const hasAutopilot = await dbProxy.schema.hasColumn('conversations', 'is_autopilot');
    if (!hasAutopilot) {
      await dbProxy.schema.table('conversations', (table) => {
        table.integer('is_autopilot').defaultTo(1);
      });
    }
    const hasIntent = await dbProxy.schema.hasColumn('conversations', 'intent');
    if (!hasIntent) {
      await dbProxy.schema.table('conversations', (table) => {
        table.string('intent');
        table.float('engagement_score').defaultTo(0);
      });
    }
    const hasLastMessage = await dbProxy.schema.hasColumn('conversations', 'last_message');
    if (!hasLastMessage) {
      await dbProxy.schema.table('conversations', (table) => {
        table.text('last_message');
      });
    }
    const hasProfilePicConv = await dbProxy.schema.hasColumn('conversations', 'profile_pic');
    if (!hasProfilePicConv) {
      await dbProxy.schema.table('conversations', (table) => {
        table.text('profile_pic');
      });
    }
    const hasIsGroup = await dbProxy.schema.hasColumn('conversations', 'is_group');
    if (!hasIsGroup) {
      await dbProxy.schema.table('conversations', (table) => {
        table.integer('is_group').defaultTo(0);
      });
    }
  }

  const hasStatuses = await dbProxy.schema.hasTable('whatsapp_statuses');
  if (!hasStatuses) {
    await dbProxy.schema.createTable('whatsapp_statuses', (table) => {
      table.increments('id').primary();
      table.integer('session_id').unsigned().references('id').inTable('whatsapp_sessions').onDelete('CASCADE');
      table.string('contact_number').notNullable();
      table.string('contact_name');
      table.text('content');
      table.string('type').defaultTo('text'); // 'text', 'image', 'video'
      table.text('media_url');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  }

  const hasLeads = await dbProxy.schema.hasTable('leads');
  if (!hasLeads) {
    await dbProxy.schema.createTable('leads', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.integer('conversation_id').unsigned().references('id').inTable('conversations').onDelete('SET NULL');
      table.string('contact_number').nullable();
      table.string('name');
      table.string('email');
      table.string('website');
      table.string('source').defaultTo('WhatsApp');
      table.string('status').defaultTo('New'); // New, Contacted, Qualified, Final Customer, Not Interested
      table.string('service_interest');
      table.text('objections');
      table.integer('is_new').defaultTo(1);
      table.integer('followup_count').defaultTo(0);
      table.timestamp('last_followup_at');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
      table.timestamp('updated_at').defaultTo(dbProxy.fn.now());
    });
  } else {
    const hasFollowupCount = await dbProxy.schema.hasColumn('leads', 'followup_count');
    if (!hasFollowupCount) {
      await dbProxy.schema.table('leads', (table) => {
        table.integer('followup_count').defaultTo(0);
        table.timestamp('last_followup_at');
      });
    }
    const hasConvId = await dbProxy.schema.hasColumn('leads', 'conversation_id');
    if (!hasConvId) {
      await dbProxy.schema.table('leads', (table) => {
        table.integer('conversation_id').unsigned().references('id').inTable('conversations').onDelete('CASCADE');
      });
    }
    const hasServiceInterest = await dbProxy.schema.hasColumn('leads', 'service_interest');
    if (!hasServiceInterest) {
      await dbProxy.schema.table('leads', (table) => {
        table.string('service_interest');
        table.text('objections');
      });
    }
    const hasQualifiedAt = await dbProxy.schema.hasColumn('leads', 'qualified_at');
    if (!hasQualifiedAt) {
      await dbProxy.schema.table('leads', (table) => {
        table.timestamp('qualified_at');
        table.integer('manual_followup_count').defaultTo(0);
        table.integer('auto_followup_count').defaultTo(0);
      });
    }
    const hasContactNumberLead = await dbProxy.schema.hasColumn('leads', 'contact_number');
    if (!hasContactNumberLead) {
      await dbProxy.schema.table('leads', (table) => {
        table.string('contact_number').nullable();
      });
    }
    const hasUserIdConv = await dbProxy.schema.hasColumn('conversations', 'user_id');
    if (!hasUserIdConv) {
      await dbProxy.schema.table('conversations', (table) => {
        table.integer('user_id').unsigned().references('id').inTable('users').onDelete('SET NULL');
      });
    }
    const hasLabelsLead = await dbProxy.schema.hasColumn('leads', 'labels');
    if (!hasLabelsLead) {
      await dbProxy.schema.table('leads', (table) => {
        table.text('labels');
      });
    }
  }

  const hasMessages = await dbProxy.schema.hasTable('messages');
  if (!hasMessages) {
    await dbProxy.schema.createTable('messages', (table) => {
      table.increments('id').primary();
      table.integer('conversation_id').unsigned().references('id').inTable('conversations').onDelete('CASCADE');
      table.string('sender').notNullable();
      table.text('content');
      table.string('type').defaultTo('text');
      table.string('platform').defaultTo('whatsapp');
      table.text('transcription');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  } else {
    const hasPlatform = await dbProxy.schema.hasColumn('messages', 'platform');
    if (!hasPlatform) {
      await dbProxy.schema.table('messages', (table) => {
        table.string('platform').defaultTo('whatsapp');
      });
    }
    const hasIsFollowup = await dbProxy.schema.hasColumn('messages', 'is_followup');
    if (!hasIsFollowup) {
      await dbProxy.schema.table('messages', (table) => {
        table.integer('is_followup').defaultTo(0);
      });
    }
  }

  const hasCampaigns = await dbProxy.schema.hasTable('bulk_campaigns');
  if (!hasCampaigns) {
    await dbProxy.schema.createTable('bulk_campaigns', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.string('name').notNullable();
      table.text('message').notNullable();
      table.string('status').defaultTo('pending'); // pending, processing, completed, failed, paused
      table.integer('total_recipients').defaultTo(0);
      table.integer('sent_count').defaultTo(0);
      table.integer('delivered_count').defaultTo(0);
      table.integer('read_count').defaultTo(0);
      table.integer('reply_count').defaultTo(0);
      table.integer('failed_count').defaultTo(0);
      table.timestamp('scheduled_at').nullable();
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  } else {
    const hasUserId = await dbProxy.schema.hasColumn('bulk_campaigns', 'user_id');
    if (!hasUserId) {
      await dbProxy.schema.table('bulk_campaigns', (table) => {
        table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      });
    }
    const hasTotalRecipients = await dbProxy.schema.hasColumn('bulk_campaigns', 'total_recipients');
    if (!hasTotalRecipients) {
      await dbProxy.schema.table('bulk_campaigns', (table) => {
        table.integer('total_recipients').defaultTo(0);
        table.integer('sent_count').defaultTo(0);
        table.integer('delivered_count').defaultTo(0);
        table.integer('read_count').defaultTo(0);
        table.integer('reply_count').defaultTo(0);
        table.integer('failed_count').defaultTo(0);
        table.timestamp('scheduled_at').nullable();
      });
    }
  }

  const hasRecipients = await dbProxy.schema.hasTable('bulk_recipients');
  if (!hasRecipients) {
    await dbProxy.schema.createTable('bulk_recipients', (table) => {
      table.increments('id').primary();
      table.integer('campaign_id').unsigned().references('id').inTable('bulk_campaigns').onDelete('CASCADE');
      table.string('number').notNullable();
      table.string('status').defaultTo('pending'); // pending, sent, delivered, read, replied, failed
      table.timestamp('sent_at').nullable();
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  }

  const hasContacts = await dbProxy.schema.hasTable('contacts');
  if (!hasContacts) {
    await dbProxy.schema.createTable('contacts', (table) => {
      table.increments('id').primary();
      table.integer('session_id').unsigned().references('id').inTable('whatsapp_sessions').onDelete('CASCADE');
      table.string('jid').notNullable();
      table.string('name');
      table.string('number');
      table.text('profile_pic');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
      table.unique(['session_id', 'jid']);
    });
  } else {
    const hasProfilePic = await dbProxy.schema.hasColumn('contacts', 'profile_pic');
    if (!hasProfilePic) {
      await dbProxy.schema.table('contacts', (table) => {
        table.text('profile_pic');
      });
    }
  }

  const hasAgentRules = await dbProxy.schema.hasTable('agent_rules');
  if (!hasAgentRules) {
    await dbProxy.schema.createTable('agent_rules', (table) => {
      table.increments('id').primary();
      table.integer('agent_id').unsigned().references('id').inTable('agents').onDelete('CASCADE');
      table.string('trigger_type').notNullable(); // 'url_shared', 'keyword_match', 'sender_match'
      table.text('trigger_value');
      table.string('action_type').notNullable(); // 'forward_to_group', 'reply_with_template', 'notify_admin'
      table.text('action_value');
      table.text('description');
      table.integer('is_active').defaultTo(1);
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  }

  const hasTrainingFiles = await dbProxy.schema.hasTable('training_files');
  if (!hasTrainingFiles) {
    await dbProxy.schema.createTable('training_files', (table) => {
      table.increments('id').primary();
      table.integer('agent_id').unsigned().references('id').inTable('agents').onDelete('CASCADE');
      table.string('filename').notNullable();
      table.string('original_name').notNullable();
      table.string('category').defaultTo('training'); // 'training', 'portfolio', 'rules'
      table.text('content');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  }

  const hasCategory = await dbProxy.schema.hasColumn('training_files', 'category');
  if (!hasCategory) {
    await dbProxy.schema.table('training_files', (table) => {
      table.string('category').defaultTo('training');
    });
  }

  const hasSettings = await dbProxy.schema.hasTable('settings');
  if (!hasSettings) {
    await dbProxy.schema.createTable('settings', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.string('provider').notNullable();
      table.string('api_key').notNullable();
      table.string('base_url');
      table.string('model');
      table.string('category').defaultTo('ai'); // 'ai' or 'voice'
      table.integer('is_active').defaultTo(1);
      table.string('status').defaultTo('active');
      table.float('credits_remaining').defaultTo(0);
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  } else {
    const hasCategory = await dbProxy.schema.hasColumn('settings', 'category');
    if (!hasCategory) {
      await dbProxy.schema.table('settings', (table) => {
        table.string('category').defaultTo('ai');
      });
    }
  }

  const hasUserWebsites = await dbProxy.schema.hasTable('user_websites');
  if (!hasUserWebsites) {
    await dbProxy.schema.createTable('user_websites', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.string('url').notNullable();
      table.string('status').defaultTo('added'); // 'added', 'audited'
      table.integer('is_active').defaultTo(0);
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  } else {
    const hasIsActive = await dbProxy.schema.hasColumn('user_websites', 'is_active');
    if (!hasIsActive) {
      await dbProxy.schema.table('user_websites', (table) => {
        table.integer('is_active').defaultTo(0);
      });
    }
  }

  const hasSocialAccounts = await dbProxy.schema.hasTable('social_accounts');
  if (!hasSocialAccounts) {
    await dbProxy.schema.createTable('social_accounts', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.string('platform').notNullable(); // 'facebook', 'instagram'
      table.string('account_id').notNullable();
      table.string('name');
      table.text('access_token');
      table.text('avatar');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
      table.unique(['user_id', 'platform', 'account_id']);
    });
  }

  const hasCampaignHistory = await dbProxy.schema.hasTable('campaign_history');
  if (!hasCampaignHistory) {
    await dbProxy.schema.createTable('campaign_history', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.integer('lead_id').unsigned().references('id').inTable('leads').onDelete('CASCADE');
      table.text('message').notNullable();
      table.string('status').defaultTo('sent'); // sent, failed
      table.text('file_url');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  }

  const hasCampaignConfigs = await dbProxy.schema.hasTable('campaign_configs');
  if (!hasCampaignConfigs) {
    await dbProxy.schema.createTable('campaign_configs', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.string('business_name');
      table.string('service_type');
      table.text('primary_offer');
      table.integer('daily_message_limit').defaultTo(50);
      table.integer('min_delay').defaultTo(10);
      table.integer('max_delay').defaultTo(60);
      table.integer('max_followups').defaultTo(3);
      table.integer('stop_if_no_reply').defaultTo(1);
      table.integer('enable_ai_rewriting').defaultTo(1);
      table.string('ai_tone').defaultTo('Professional');
      table.integer('user_consent_required').defaultTo(1);
      table.integer('is_followup_enabled').defaultTo(0);
      table.text('followup_statuses'); // JSON array of statuses
      table.text('automation_rules'); // JSON string for stage rules
      table.timestamp('updated_at').defaultTo(dbProxy.fn.now());
    });
  } else {
    const hasFollowupEnabled = await dbProxy.schema.hasColumn('campaign_configs', 'is_followup_enabled');
    if (!hasFollowupEnabled) {
      await dbProxy.schema.table('campaign_configs', (table) => {
        table.integer('is_followup_enabled').defaultTo(0);
        table.text('followup_statuses');
      });
    }
  }

  const hasFollowupLogs = await dbProxy.schema.hasTable('followup_logs');
  if (!hasFollowupLogs) {
    await dbProxy.schema.createTable('followup_logs', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.integer('lead_id').unsigned().references('id').inTable('leads').onDelete('CASCADE');
      table.string('status').defaultTo('pending'); // pending, sent, failed
      table.text('message');
      table.timestamp('sent_at');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  }

  const hasBlacklist = await dbProxy.schema.hasTable('blacklist');
  if (!hasBlacklist) {
    await dbProxy.schema.createTable('blacklist', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.string('number').notNullable();
      table.string('reason');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
      table.unique(['user_id', 'number']);
    });
  }

  const hasOptIns = await dbProxy.schema.hasTable('opt_ins');
  if (!hasOptIns) {
    await dbProxy.schema.createTable('opt_ins', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.string('number').notNullable();
      table.string('source').defaultTo('Manual Entry');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
      table.unique(['user_id', 'number']);
    });
  }

  const hasWALabels = await dbProxy.schema.hasTable('whatsapp_labels');
  if (!hasWALabels) {
    await dbProxy.schema.createTable('whatsapp_labels', (table) => {
      table.increments('id').primary();
      table.integer('session_id').unsigned().references('id').inTable('whatsapp_sessions').onDelete('CASCADE');
      table.string('label_id').notNullable();
      table.string('name').notNullable();
      table.string('color');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
      table.unique(['session_id', 'label_id']);
    });
  }

  const hasImageCollections = await dbProxy.schema.hasTable('agent_image_collections');
  if (!hasImageCollections) {
    await dbProxy.schema.createTable('agent_image_collections', (table) => {
      table.increments('id').primary();
      table.integer('agent_id').unsigned().references('id').inTable('agents').onDelete('CASCADE');
      table.string('name').notNullable();
      table.text('description');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  }

  const hasAgentImages = await dbProxy.schema.hasTable('agent_images');
  if (!hasAgentImages) {
    await dbProxy.schema.createTable('agent_images', (table) => {
      table.increments('id').primary();
      table.integer('collection_id').unsigned().references('id').inTable('agent_image_collections').onDelete('CASCADE');
      table.string('filename').notNullable();
      table.string('original_name').notNullable();
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  }

  const hasImageColType = await dbProxy.schema.hasColumn('agent_image_collections', 'type');
  if (!hasImageColType) {
    await dbProxy.schema.table('agent_image_collections', (table) => {
      table.string('type').defaultTo('standard'); // 'standard' or 'catalog'
    });
  }

  // Update agent_images to include price and link
  const hasImagePrice = await dbProxy.schema.hasColumn('agent_images', 'price');
  if (!hasImagePrice) {
    await dbProxy.schema.table('agent_images', (table) => {
      table.string('price').nullable();
      table.text('link').nullable();
    });
  }

  const hasActivities = await dbProxy.schema.hasTable('activities');
  if (!hasActivities) {
    await dbProxy.schema.createTable('activities', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.string('type').notNullable(); // 'lead_added', 'lead_qualified', 'followup_sent', 'customer_converted', 'message_received'
      table.text('description');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  }

  const hasAuditLogs = await dbProxy.schema.hasTable('audit_logs');
  if (!hasAuditLogs) {
    await dbProxy.schema.createTable('audit_logs', (table) => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.string('action').notNullable();
      table.text('details');
      table.timestamp('created_at').defaultTo(dbProxy.fn.now());
    });
  }

  console.log(`Database initialized successfully using ${isMySQL ? 'MySQL' : 'SQLite'} - Handlingo`);
}

// Helper to bridge better-sqlite3 style calls to knex (for minimal refactoring)
const dbWrapper = {
  prepare: (sql: string) => {
    return {
      all: async (...args: any[]) => {
        try {
          const bindings = Array.isArray(args[0]) ? args[0] : args;
          const result = await dbProxy.raw(sql, bindings);
          return isMySQL ? result[0] : result;
        } catch (err: any) {
          console.error(`DB Error (all) - SQL: ${sql} - Bindings: ${JSON.stringify(args)}`, err.message);
          throw err;
        }
      },
      get: async (...args: any[]) => {
        try {
          const bindings = Array.isArray(args[0]) ? args[0] : args;
          const result = await dbProxy.raw(sql, bindings);
          const rows = isMySQL ? result[0] : result;
          return rows[0];
        } catch (err: any) {
          console.error(`DB Error (get) - SQL: ${sql} - Bindings: ${JSON.stringify(args)}`, err.message);
          throw err;
        }
      },
      run: async (...args: any[]) => {
        try {
          const bindings = Array.isArray(args[0]) ? args[0] : args;
          const result = await dbProxy.raw(sql, bindings);
          if (isMySQL) {
            return { lastInsertRowid: result[0].insertId };
          } else {
            return { lastInsertRowid: result.lastInsertRowid || result[0]?.id };
          }
        } catch (err: any) {
          console.error(`DB Error (run) - SQL: ${sql} - Bindings: ${JSON.stringify(args)}`, err.message);
          throw err;
        }
      }
    };
  },
  exec: async (sql: string) => {
    try {
      return await dbProxy.raw(sql);
    } catch (err: any) {
      console.error(`DB Error (exec) - SQL: ${sql}`, err.message);
      throw err;
    }
  }
};

export { initDb, dbProxy as knex, isMySQL };
export default dbWrapper;