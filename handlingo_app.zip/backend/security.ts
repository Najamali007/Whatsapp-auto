import nodemailer from 'nodemailer';
import { rateLimit } from 'express-rate-limit';
import helmet from 'helmet';
import dotenv from 'dotenv';
dotenv.config();

// ============================================================
// EMAIL SETUP — Gmail SMTP (Free)
// .env mein yeh add karo:
// EMAIL_USER=aapki_gmail@gmail.com
// EMAIL_PASS=gmail_app_password  (Gmail App Password)
// ============================================================

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER || '',
    pass: process.env.EMAIL_PASS || '',
  },
});

export async function sendEmail(to: string, subject: string, html: string) {
  if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
    console.warn('[Email] EMAIL_USER or EMAIL_PASS not set in .env — email not sent');
    return false;
  }
  try {
    await transporter.sendMail({
      from: `"Handlingo System" <${process.env.EMAIL_USER}>`,
      to,
      subject,
      html,
    });
    console.log(`[Email] Sent to ${to}: ${subject}`);
    return true;
  } catch (err: any) {
    console.error('[Email] Send failed:', err.message);
    return false;
  }
}

// ============================================================
// OTP STORE — in-memory (server restart pe clear ho jata hai)
// Format: { email: { otp, expiry, attempts } }
// ============================================================

interface OtpEntry {
  otp: string;
  expiry: number;    // timestamp ms
  attempts: number;
}

const otpStore = new Map<string, OtpEntry>();

export function generateOtp(): string {
  return Math.floor(100000 + Math.random() * 900000).toString(); // 6 digit
}

export function storeOtp(email: string, otp: string) {
  otpStore.set(email.toLowerCase(), {
    otp,
    expiry: Date.now() + 10 * 60 * 1000, // 10 minutes
    attempts: 0,
  });
}

export function verifyOtp(email: string, inputOtp: string): { valid: boolean; error?: string } {
  const entry = otpStore.get(email.toLowerCase());
  if (!entry) return { valid: false, error: 'OTP not found or expired' };
  if (Date.now() > entry.expiry) {
    otpStore.delete(email.toLowerCase());
    return { valid: false, error: 'OTP has expired. Please request a new one.' };
  }
  entry.attempts++;
  if (entry.attempts > 5) {
    otpStore.delete(email.toLowerCase());
    return { valid: false, error: 'Too many failed attempts. Please request a new OTP.' };
  }
  if (entry.otp !== inputOtp) {
    return { valid: false, error: 'Invalid OTP. Please try again.' };
  }
  otpStore.delete(email.toLowerCase()); // Use once
  return { valid: true };
}

// ============================================================
// PASSWORD RESET TOKENS — in-memory
// ============================================================

interface ResetEntry {
  userId: number;
  expiry: number;
}

const resetStore = new Map<string, ResetEntry>();

export function generateResetToken(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

export function storeResetToken(token: string, userId: number) {
  resetStore.set(token, {
    userId,
    expiry: Date.now() + 30 * 60 * 1000, // 30 minutes
  });
}

export function verifyResetToken(token: string): { valid: boolean; userId?: number; error?: string } {
  const entry = resetStore.get(token);
  if (!entry) return { valid: false, error: 'Invalid or expired reset link' };
  if (Date.now() > entry.expiry) {
    resetStore.delete(token);
    return { valid: false, error: 'Reset link has expired. Please request a new one.' };
  }
  resetStore.delete(token); // Use once
  return { valid: true, userId: entry.userId };
}

// ============================================================
// RATE LIMITERS
// ============================================================

// Login pe — 10 attempts per 15 minutes per IP
export const loginRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 4,
  message: { error: 'Too many login attempts. Please try again after 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// OTP send pe — 5 requests per 15 minutes per IP
export const otpRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: { error: 'Too many OTP requests. Please try again after 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// General API — 200 requests per minute per IP
export const apiRateLimit = rateLimit({
  windowMs: 60 * 1000,
  max: 200,
  message: { error: 'Too many requests. Please slow down.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// ============================================================
// HELMET — HTTP Security Headers
// ============================================================

export const helmetMiddleware = helmet({
  contentSecurityPolicy: false, // React app ke liye off
  crossOriginEmbedderPolicy: false,
});

// ============================================================
// EMAIL TEMPLATES
// ============================================================

export function otpEmailTemplate(otp: string, type: 'login' | 'reset'): string {
  const title = type === 'login' ? '2-Step Verification Code' : 'Password Reset Code';
  const msg = type === 'login'
    ? 'Use this OTP to complete your login. Valid for 10 minutes.'
    : 'Use this OTP to reset your password. Valid for 10 minutes.';

  return `
    <div style="font-family: Arial, sans-serif; max-width: 480px; margin: 0 auto; background: #f9f9f9; padding: 32px; border-radius: 12px;">
      <div style="text-align: center; margin-bottom: 24px;">
        <h1 style="color: #111; font-size: 22px; margin: 0;">Handlingo</h1>
        <p style="color: #888; font-size: 12px; margin: 4px 0 0;">Automate. Engage. Grow.</p>
      </div>
      <h2 style="color: #222; font-size: 18px;">${title}</h2>
      <p style="color: #555; font-size: 14px;">${msg}</p>
      <div style="background: #111; color: #fff; font-size: 36px; font-weight: bold; letter-spacing: 12px; text-align: center; padding: 20px; border-radius: 8px; margin: 24px 0;">
        ${otp}
      </div>
      <p style="color: #999; font-size: 12px;">If you did not request this, please ignore this email. Do not share this code with anyone.</p>
    </div>
  `;
}
