import React, { useState, useEffect } from 'react';
import { 
  Globe, 
  Plus, 
  Pin, 
  Loader2, 
  ExternalLink, 
  Shield, 
  CheckCircle2, 
  Clock,
  Search,
  Filter,
  ArrowRight,
  Monitor,
  Layout,
  MousePointer2,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { apiFetch } from '../lib/api';

interface Website {
  id: number;
  url: string;
  status: 'added' | 'audited';
  is_active: number;
  created_at: string;
}

export default function Tracking({ token }: { token: string | null }) {
  const [websites, setWebsites] = useState<Website[]>([]);
  const [newWebsite, setNewWebsite] = useState('');
  const [addingWebsite, setAddingWebsite] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isGlobalActive, setIsGlobalActive] = useState(false);
  const [togglingGlobal, setTogglingGlobal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<'all' | 'added' | 'audited'>('all');
  const [showDetails, setShowDetails] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  useEffect(() => {
    if (!token) return;
    fetchWebsites();
    fetchGlobalStatus();
  }, [token]);

  const fetchWebsites = async () => {
    try {
      const data = await apiFetch('/api/user-websites');
      setWebsites(data);
    } catch (err) {
      console.error('Failed to fetch websites:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchGlobalStatus = async () => {
    try {
      const data = await apiFetch('/api/settings/tracking');
      setIsGlobalActive(data.is_active);
    } catch (err) {
      console.error('Failed to fetch tracking stats:', err);
    }
  };

  const handleToggleGlobal = async (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setTogglingGlobal(true);
    try {
      const data = await apiFetch('/api/settings/tracking', {
        method: 'POST',
        body: JSON.stringify({ is_active: !isGlobalActive })
      });
      setIsGlobalActive(data.is_active);
    } catch (err) {
      console.error('Failed to toggle tracking:', err);
    } finally {
      setTogglingGlobal(false);
    }
  };

  const handleAddWebsite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWebsite) return;
    setAddingWebsite(true);
    try {
      const data = await apiFetch('/api/user-websites', {
        method: 'POST',
        body: JSON.stringify({ url: newWebsite })
      });
      setWebsites([data, ...websites]);
      setNewWebsite('');
    } catch (err) {
      console.error('Failed to add website:', err);
    } finally {
      setAddingWebsite(false);
    }
  };

  const handleDeleteWebsite = async (id: number) => {
    try {
      await apiFetch(`/api/user-websites/${id}`, { method: 'DELETE' });
      setWebsites(websites.filter(w => w.id !== id));
      setDeletingId(null);
    } catch (err) {
      console.error('Failed to delete website:', err);
    }
  };

  const handleAuditWebsite = async (id: number) => {
    try {
      const data = await apiFetch(`/api/user-websites/${id}/audit`, { method: 'POST' });
      setWebsites(websites.map(w => w.id === id ? { ...w, status: data.status } : w));
    } catch (err) {
      console.error('Failed to audit website:', err);
    }
  };

  const handleToggleSiteActive = async (id: number, currentActive: number) => {
    try {
      const data = await apiFetch(`/api/user-websites/${id}/active`, {
        method: 'PATCH',
        body: JSON.stringify({ is_active: !currentActive })
      });
      setWebsites(websites.map(w => w.id === id ? { ...w, is_active: data.is_active ? 1 : 0 } : w));
    } catch (err) {
      console.error('Failed to toggle website status:', err);
    }
  };

  const filteredWebsites = websites.filter(site => {
    const matchesSearch = site.url.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filter === 'all' || site.status === filter;
    return matchesSearch && matchesFilter;
  });

  if (!showDetails) {
    return (
      <div className="max-w-6xl mx-auto space-y-8 pb-12">
        <div className="flex items-center gap-3 mb-8">
          <div className="p-2 bg-primary/10 rounded-xl">
            <Globe className="w-6 h-6 text-primary" />
          </div>
          <h1 className="text-3xl font-black text-gray-900 tracking-tight uppercase">Tracking</h1>
        </div>

        <motion.div 
          onClick={() => setShowDetails(true)}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="group cursor-pointer bg-white p-8 rounded-[3rem] border-2 border-transparent hover:border-primary/20 shadow-xl shadow-gray-200/50 transition-all relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -mr-32 -mt-32 group-hover:bg-primary/10 transition-colors" />
          
          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-14 h-14 bg-gray-900 rounded-2xl flex items-center justify-center text-primary shadow-xl shadow-gray-900/20">
                  <Monitor className="w-7 h-7" />
                </div>
                <div>
                  <h2 className="text-2xl font-black text-gray-900 uppercase tracking-tight">Website Audit Tracker</h2>
                  <p className="text-gray-500 font-medium">Manage and automate follow-ups for monitored websites</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8">
                <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Websites</p>
                  <p className="text-xl font-black text-gray-900">{websites.length}</p>
                </div>
                <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
                  <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mb-1">Audited</p>
                  <p className="text-xl font-black text-emerald-600">{websites.filter(w => w.status === 'audited').length}</p>
                </div>
                <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100">
                  <p className="text-[10px] font-black text-amber-400 uppercase tracking-widest mb-1">Awaiting</p>
                  <p className="text-xl font-black text-amber-600">{websites.filter(w => w.status === 'added').length}</p>
                </div>
                <div className="p-4 bg-primary/10 rounded-2xl border border-primary/20">
                  <p className="text-[10px] font-black text-primary uppercase tracking-widest mb-1">Status</p>
                  <p className={`text-sm font-black ${isGlobalActive ? 'text-primary' : 'text-gray-400'}`}>
                    {isGlobalActive ? 'ACTIVE' : 'INACTIVE'}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-center gap-4">
              <div className="flex items-center gap-4 bg-gray-50 p-4 rounded-3xl border border-gray-100">
                <div className="text-right">
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Automation</p>
                  <p className={`text-[10px] font-black ${isGlobalActive ? 'text-primary' : 'text-gray-400'}`}>
                    {isGlobalActive ? 'LOGIC ON' : 'LOGIC OFF'}
                  </p>
                </div>
                <button
                  onClick={handleToggleGlobal}
                  disabled={togglingGlobal}
                  className={`relative inline-flex h-8 w-14 items-center rounded-full transition-all duration-300 focus:outline-none ${
                    isGlobalActive ? 'bg-primary' : 'bg-gray-300'
                  }`}
                >
                  <span
                    className={`inline-block h-6 w-6 transform rounded-full bg-white transition-all duration-300 shadow-md ${
                      isGlobalActive ? 'translate-x-[24px]' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <button className="flex items-center gap-2 group-hover:gap-4 transition-all text-primary font-black text-xs uppercase tracking-widest">
                Manage Details <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12 uppercase tracking-tight">
      {/* Detail Header */}
      <div className="flex items-center justify-between mb-8">
        <button 
          onClick={() => setShowDetails(false)}
          className="flex items-center gap-2 text-gray-400 hover:text-gray-900 transition-colors font-black text-xs uppercase tracking-widest"
        >
          <ArrowRight className="w-4 h-4 rotate-180" /> Back to Dashboard
        </button>
      </div>

      {/* Header with Global Switch */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -mr-32 -mt-32" />
        
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-primary/10 rounded-xl">
              <Globe className="w-6 h-6 text-primary" />
            </div>
            <h1 className="text-3xl font-black text-gray-900 tracking-tight uppercase">Website Tracking</h1>
          </div>
          <p className="text-gray-500 font-medium max-w-md">
            Manage websites for free audits. When active, AI agents will automatically detect shared URLs and track their audit status for follow-ups.
          </p>
        </div>

        <div className="flex items-center gap-4 bg-gray-50 p-4 rounded-3xl border border-gray-100 relative z-10">
          <div className="text-right">
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">
              Global Automation
            </p>
            <p className={`text-sm font-black ${isGlobalActive ? 'text-primary' : 'text-gray-400'}`}>
              {isGlobalActive ? 'LOGIC ACTIVE' : 'LOGIC INACTIVE'}
            </p>
          </div>
          <button
            onClick={() => handleToggleGlobal()}
            disabled={togglingGlobal}
            className={`relative inline-flex h-10 w-20 items-center rounded-full transition-all duration-300 focus:outline-none ${
              isGlobalActive ? 'bg-primary' : 'bg-gray-300'
            }`}
          >
           <span className="sr-only">Toggle Global Tracking</span>
            <span
              className={`inline-block h-8 w-8 transform rounded-full bg-white transition-all duration-300 shadow-md ${
                isGlobalActive ? 'translate-x-[44px]' : 'translate-x-1'
              } flex items-center justify-center`}
            >
              {togglingGlobal ? (
                <Loader2 className="w-4 h-4 animate-spin text-gray-400" />
              ) : (
                <Shield className={`w-4 h-4 ${isGlobalActive ? 'text-primary' : 'text-gray-400'}`} />
              )}
            </span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 text-black">
        {/* Left Column: Add & Stats */}
        <div className="lg:col-span-1 space-y-6">
          <section className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm">
            <h3 className="text-sm font-black text-gray-900 uppercase tracking-widest mb-4 flex items-center gap-2">
              <Plus className="w-4 h-4 text-primary" />
              Track New Website
            </h3>
            <form onSubmit={handleAddWebsite} className="space-y-4">
              <div className="relative group">
                <Layout className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 group-focus-within:text-primary transition-colors" />
                <input
                  type="text"
                  value={newWebsite}
                  onChange={(e) => setNewWebsite(e.target.value)}
                  placeholder="domain.com"
                  className="w-full bg-gray-50 border-2 border-gray-100 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold focus:bg-white focus:border-primary outline-none transition-all"
                />
              </div>
              <button
                type="submit"
                disabled={addingWebsite || !newWebsite}
                className="w-full bg-gray-900 text-white p-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-gray-800 disabled:opacity-50 transition-all shadow-xl shadow-gray-900/10 flex items-center justify-center gap-2"
              >
                {addingWebsite ? <Loader2 className="w-4 h-4 animate-spin" /> : <Shield className="w-4 h-4" />}
                Start Tracking
              </button>
            </form>
          </section>

          <section className="bg-gray-900 p-6 rounded-[2rem] text-white shadow-xl shadow-gray-900/10">
            <h3 className="text-xs font-black text-primary uppercase tracking-[0.2em] mb-4">Tracking Overview</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Total</p>
                <p className="text-2xl font-black">{websites.length}</p>
              </div>
              <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Audited</p>
                <p className="text-2xl font-black text-primary">{websites.filter(w => w.status === 'audited').length}</p>
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-white/5 rounded-2xl border border-white/10 flex items-center gap-4">
              <div className="w-10 h-10 bg-primary/20 rounded-xl flex items-center justify-center text-primary">
                <Monitor className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-0.5">Automated Tasks</p>
                <p className="text-xs font-bold">Bot handles follow-ups based on these links</p>
              </div>
            </div>
          </section>
        </div>

        {/* Right Column: List */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative w-full md:w-64 text-black">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="text"
                placeholder="Search websites..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-gray-50 border-none rounded-xl py-2 pl-10 pr-4 text-sm font-medium focus:ring-2 focus:ring-primary transition-all"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <select 
                value={filter}
                onChange={(e) => setFilter(e.target.value as any)}
                className="bg-gray-50 border-none rounded-xl py-2 pl-3 pr-8 text-sm font-bold text-gray-700 focus:ring-2 focus:ring-primary"
              >
                <option value="all">All Sites</option>
                <option value="added">Awaiting Audit</option>
                <option value="audited">Audited</option>
              </select>
            </div>
          </div>

          <div className="space-y-4">
            {loading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="bg-white h-24 rounded-3xl animate-pulse" />
              ))
            ) : filteredWebsites.length === 0 ? (
              <div className="bg-white p-12 rounded-[2.5rem] border border-gray-100 shadow-sm text-center">
                <div className="w-16 h-16 bg-gray-50 rounded-2xl flex items-center justify-center mx-auto mb-4 text-gray-300">
                  <Globe className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-black text-gray-900 uppercase">No Websites Found</h3>
                <p className="text-gray-500 mt-2 font-medium">Add a website to start tracking and automate follow-ups.</p>
              </div>
            ) : (
              <AnimatePresence mode="popLayout">
                {filteredWebsites.map((site) => (
                  <motion.div
                    key={site.id}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="bg-white p-6 rounded-[2.2rem] border border-gray-100 shadow-sm hover:shadow-md transition-all group"
                  >
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex items-center gap-4 flex-1 min-w-0">
                        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-sm transition-colors ${
                          site.status === 'audited' ? 'bg-emerald-50 text-emerald-500' : 'bg-amber-50 text-amber-500'
                        }`}>
                          {site.status === 'audited' ? <CheckCircle2 className="w-6 h-6" /> : <Clock className="w-6 h-6" />}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <h4 className="text-sm font-black text-gray-900 truncate uppercase tracking-tight">{site.url}</h4>
                            <a 
                              href={site.url.startsWith('http') ? site.url : `https://${site.url}`} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="p-1 hover:bg-gray-100 rounded text-gray-400 hover:text-primary transition-colors"
                            >
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          </div>
                          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">
                            Added on {new Date(site.created_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        {site.status === 'added' && (
                          <button
                            onClick={() => handleAuditWebsite(site.id)}
                            className="px-4 py-2 bg-indigo-50 text-indigo-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-100 transition-all flex items-center gap-2"
                          >
                            Mark Audited
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        )}
                        
                        <div className="h-8 w-px bg-gray-100 mx-1" />
                        
                        <button
                          onClick={() => handleToggleSiteActive(site.id, site.is_active)}
                          className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                            site.is_active ? 'bg-emerald-50 text-emerald-600' : 'bg-gray-50 text-gray-400'
                          }`}
                          title={site.is_active ? "Tracking Active" : "Tracking Inactive"}
                        >
                          <MousePointer2 className={`w-5 h-5 ${site.is_active ? 'fill-emerald-600/20' : ''}`} />
                        </button>

                        <button
                          onClick={() => setDeletingId(site.id)}
                          className="w-10 h-10 rounded-xl bg-rose-50 text-rose-500 flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 hover:bg-rose-100"
                        >
                          <Pin className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            )}
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {deletingId !== null && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-md overflow-hidden border border-gray-100 p-8"
            >
              <div className="w-16 h-16 bg-rose-50 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <AlertCircle className="w-8 h-8 text-rose-500" />
              </div>
              <h3 className="text-2xl font-black text-gray-900 text-center uppercase tracking-tighter mb-4">Confirm Deletion</h3>
              <p className="text-gray-500 text-center font-medium mb-8">
                Are you sure you want to remove this website from tracking? This action cannot be undone.
              </p>
              <div className="flex flex-col gap-3">
                <button
                  onClick={() => deletingId && handleDeleteWebsite(deletingId)}
                  className="w-full py-4 bg-rose-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-rose-700 transition-all shadow-xl shadow-rose-600/20"
                >
                  Yes, Remove Website
                </button>
                <button
                  onClick={() => setDeletingId(null)}
                  className="w-full py-4 bg-gray-100 text-gray-800 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-gray-200 transition-all"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
