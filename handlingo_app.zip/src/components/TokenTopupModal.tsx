import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Copy, Check, Upload, Loader2, CreditCard, Coins, ChevronRight, Building2, Smartphone } from 'lucide-react';
import { apiFetch } from '../lib/api';

interface Package {
  id: string;
  label: string;
  tokens: number;
  usd: number;
  local_price: number;
  currency: string;
  symbol: string;
  badge?: string;
}

interface BillingData {
  packages: Package[];
  pricePerToken: number;
  localPricePerToken: number;
  currency: string;
  symbol: string;
  rate: number;
  bankDetails: {
    bankName: string;
    accountName: string;
    accountNumber: string;
    iban: string;
    easypaisa: string;
    easypaisaName: string;
  };
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export default function TokenTopupModal({ isOpen, onClose }: Props) {
  const [billingData, setBillingData] = useState<BillingData | null>(null);
  const [selectedPackage, setSelectedPackage] = useState<Package | null>(null);
  const [customTokens, setCustomTokens] = useState('');
  const [showPaymentPopup, setShowPaymentPopup] = useState(false);
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [history, setHistory] = useState<any[]>([]);
  const [currentTokens, setCurrentTokens] = useState(0);
  const [activeTab, setActiveTab] = useState<'topup' | 'history'>('topup');

  useEffect(() => {
    if (!isOpen) return;
    setLoading(true);
    Promise.all([
      fetch('/api/billing/packages').then(r => r.json()),
      apiFetch('/api/billing/history'),
    ]).then(([pkg, hist]) => {
      setBillingData(pkg);
      setHistory(hist.requests || []);
      setCurrentTokens(hist.tokens || 0);
    }).catch(console.error)
    .finally(() => setLoading(false));
  }, [isOpen]);

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const getSelectedTokens = () => {
    if (selectedPackage) return selectedPackage.tokens;
    return parseInt(customTokens) || 0;
  };

  const getSelectedAmount = () => {
    if (selectedPackage) return selectedPackage.usd;
    const tokens = parseInt(customTokens) || 0;
    return +(tokens * (billingData?.pricePerToken || 0.02)).toFixed(2);
  };

  const getLocalAmount = () => {
    if (selectedPackage) return `${selectedPackage.symbol}${selectedPackage.local_price.toLocaleString()}`;
    const tokens = parseInt(customTokens) || 0;
    const rate = billingData?.rate || 1;
    const sym = billingData?.symbol || '$';
    return `${sym}${Math.round(tokens * (billingData?.pricePerToken || 0.02) * rate).toLocaleString()}`;
  };

  const handleProceed = () => {
    const tokens = getSelectedTokens();
    if (tokens < 100) return;
    setShowPaymentPopup(true);
  };

  const handleSubmit = async () => {
    if (!screenshot) return;
    setIsSubmitting(true);
    try {
      const form = new FormData();
      form.append('tokens_requested', getSelectedTokens().toString());
      form.append('amount_usd', getSelectedAmount().toString());
      form.append('package_label', selectedPackage?.label || 'Custom');
      form.append('screenshot', screenshot);
      const res = await fetch('/api/billing/request', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
        body: form,
      });
      if (res.ok) {
        setSubmitted(true);
        setShowPaymentPopup(false);
        setSelectedPackage(null);
        setCustomTokens('');
        setScreenshot(null);
      }
    } catch (e) { console.error(e); }
    finally { setIsSubmitting(false); }
  };

  const getStatusBadge = (status: string) => {
    if (status === 'approved') return 'bg-emerald-100 text-emerald-700';
    if (status === 'rejected') return 'bg-red-100 text-red-700';
    return 'bg-amber-100 text-amber-700';
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden border border-gray-100 flex flex-col">

        {/* Header */}
        <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-gray-900 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/10 rounded-2xl flex items-center justify-center">
              <Coins className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black uppercase tracking-tight">Token Billing</h2>
              <p className="text-xs text-white/60">Balance: <span className="font-bold text-white">{currentTokens.toLocaleString()} tokens</span></p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-xl transition-all">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-100">
          {(['topup', 'history'] as const).map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              className={`flex-1 py-3 text-xs font-black uppercase tracking-wider transition-all ${activeTab === tab ? 'border-b-2 border-gray-900 text-gray-900' : 'text-gray-400 hover:text-gray-600'}`}>
              {tab === 'topup' ? 'Top Up Tokens' : 'History'}
            </button>
          ))}
        </div>

        <div className="overflow-y-auto flex-1 p-6">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
            </div>
          ) : activeTab === 'topup' ? (
            <div className="space-y-6">
              {submitted && (
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-center">
                  <p className="text-emerald-700 font-bold text-sm">✅ Request submitted! Admin will verify and add tokens.</p>
                </div>
              )}

              {/* Packages */}
              <div>
                <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-3">Choose Package</p>
                <div className="grid grid-cols-3 gap-3">
                  {billingData?.packages.map(pkg => (
                    <button key={pkg.id} onClick={() => { setSelectedPackage(pkg); setCustomTokens(''); }}
                      className={`relative p-4 rounded-2xl border-2 text-left transition-all ${selectedPackage?.id === pkg.id ? 'border-gray-900 bg-gray-900 text-white' : 'border-gray-200 hover:border-gray-400 bg-white'}`}>
                      {pkg.badge && (
                        <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-amber-400 text-amber-900 text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider whitespace-nowrap">
                          {pkg.badge}
                        </span>
                      )}
                      <p className={`text-lg font-black ${selectedPackage?.id === pkg.id ? 'text-white' : 'text-gray-900'}`}>{pkg.tokens.toLocaleString()}</p>
                      <p className={`text-[10px] font-black uppercase tracking-wider ${selectedPackage?.id === pkg.id ? 'text-white/60' : 'text-gray-400'}`}>tokens</p>
                      <p className={`text-sm font-black mt-2 ${selectedPackage?.id === pkg.id ? 'text-white' : 'text-gray-900'}`}>
                        {pkg.symbol}{pkg.local_price.toLocaleString()}
                        {pkg.currency !== 'USD' && <span className={`text-[10px] ml-1 ${selectedPackage?.id === pkg.id ? 'text-white/50' : 'text-gray-400'}`}>(${pkg.usd})</span>}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Amount */}
              <div>
                <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Or Custom Amount</p>
                <div className="flex items-center gap-3">
                  <input type="number" min="100" placeholder="Enter tokens (min 100)"
                    className="flex-1 bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-gray-900/10 focus:border-gray-900 outline-none"
                    value={customTokens}
                    onChange={(e) => { setCustomTokens(e.target.value); setSelectedPackage(null); }} />
                  {customTokens && parseInt(customTokens) >= 100 && (
                    <div className="text-right">
                      <p className="text-sm font-black text-gray-900">{getLocalAmount()}</p>
                      <p className="text-xs text-gray-400">${getSelectedAmount()}</p>
                    </div>
                  )}
                </div>
                {billingData && (
                  <p className="text-[10px] text-gray-400 mt-1">Rate: {billingData.symbol}{+(billingData.localPricePerToken).toFixed(4)} per token</p>
                )}
              </div>

              {/* Proceed Button */}
              <button
                onClick={handleProceed}
                disabled={getSelectedTokens() < 100}
                className="w-full py-4 bg-gray-900 text-white font-black uppercase tracking-widest text-sm rounded-2xl hover:bg-gray-800 disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 shadow-xl shadow-gray-900/20">
                <CreditCard className="w-4 h-4" />
                Proceed to Payment
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {history.length === 0 ? (
                <p className="text-center text-gray-400 text-sm py-8">No payment history yet.</p>
              ) : history.map((req: any) => (
                <div key={req.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl border border-gray-100">
                  <div>
                    <p className="text-sm font-black text-gray-900">{req.tokens_requested.toLocaleString()} tokens</p>
                    <p className="text-xs text-gray-500">{req.package_label} • ${req.amount_usd}</p>
                    <p className="text-[10px] text-gray-400">{new Date(req.created_at).toLocaleDateString()}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase ${getStatusBadge(req.status)}`}>
                    {req.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </motion.div>

      {/* Payment Popup */}
      <AnimatePresence>
        {showPaymentPopup && billingData && (
          <div className="fixed inset-0 z-[210] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto border border-gray-100">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-black text-gray-900 uppercase tracking-tight">Make Payment</h3>
                  <button onClick={() => setShowPaymentPopup(false)} className="p-2 hover:bg-gray-100 rounded-xl">
                    <X className="w-5 h-5 text-gray-400" />
                  </button>
                </div>

                {/* Summary */}
                <div className="bg-gray-900 text-white rounded-2xl p-4 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Tokens</span>
                    <span className="font-black">{getSelectedTokens().toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="text-white/60">Amount</span>
                    <span className="font-black">{getLocalAmount()} <span className="text-white/40 text-xs">(${getSelectedAmount()})</span></span>
                  </div>
                </div>

                {/* Bank Details */}
                <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-3">Transfer To</p>
                <div className="space-y-2 bg-gray-50 rounded-2xl p-4 border border-gray-100">
                  {[
                    { label: 'Bank', value: billingData.bankDetails.bankName, field: 'bank' },
                    { label: 'Account Name', value: billingData.bankDetails.accountName, field: 'name' },
                    { label: 'Account No.', value: billingData.bankDetails.accountNumber, field: 'acc' },
                    { label: 'IBAN', value: billingData.bankDetails.iban, field: 'iban' },
                  ].map(item => (
                    <div key={item.field} className="flex items-center justify-between">
                      <div>
                        <p className="text-[10px] text-gray-400 font-bold">{item.label}</p>
                        <p className="text-sm font-black text-gray-900">{item.value}</p>
                      </div>
                      <button onClick={() => copyToClipboard(item.value, item.field)}
                        className="p-1.5 text-gray-400 hover:text-gray-900 transition-all">
                        {copiedField === item.field ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  ))}
                </div>

                {/* Easypaisa/JazzCash */}
                <div className="bg-emerald-50 rounded-2xl p-4 border border-emerald-100 mt-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Smartphone className="w-4 h-4 text-emerald-600" />
                    <p className="text-xs font-black text-emerald-700 uppercase tracking-wider">EasyPaisa / JazzCash</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[10px] text-emerald-600">{billingData.bankDetails.easypaisaName}</p>
                      <p className="text-sm font-black text-emerald-800">{billingData.bankDetails.easypaisa}</p>
                    </div>
                    <button onClick={() => copyToClipboard(billingData.bankDetails.easypaisa, 'ep')}
                      className="p-1.5 text-emerald-500 hover:text-emerald-700">
                      {copiedField === 'ep' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Screenshot Upload */}
                <div className="mt-4">
                  <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2">Upload Payment Screenshot</p>
                  <label className={`w-full flex flex-col items-center justify-center p-6 rounded-2xl border-2 border-dashed cursor-pointer transition-all ${screenshot ? 'border-gray-900 bg-gray-50' : 'border-gray-200 hover:border-gray-400'}`}>
                    <Upload className={`w-6 h-6 mb-2 ${screenshot ? 'text-gray-900' : 'text-gray-300'}`} />
                    <p className="text-xs font-bold text-gray-500">{screenshot ? screenshot.name : 'Click to upload screenshot'}</p>
                    <input type="file" className="hidden" accept="image/*"
                      onChange={(e) => setScreenshot(e.target.files?.[0] || null)} />
                  </label>
                </div>

                <button onClick={handleSubmit} disabled={!screenshot || isSubmitting}
                  className="w-full mt-4 py-4 bg-gray-900 text-white font-black uppercase tracking-widest text-sm rounded-2xl hover:bg-gray-800 disabled:opacity-40 transition-all flex items-center justify-center gap-2">
                  {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Submit Payment Request'}
                </button>
                <p className="text-[10px] text-gray-400 text-center mt-2">Admin will verify and add tokens within 24 hours</p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
