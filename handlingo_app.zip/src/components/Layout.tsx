import React, { useEffect, useState } from 'react';
import { 
  BarChart3,
  Bell,
  PanelLeftClose,
  PanelLeftOpen,
  LayoutDashboard, 
  Users, 
  MessageSquare, 
  QrCode, 
  Send, 
  LogOut,
  Menu,
  X,
  Plus,
  ChevronRight,
  UserCircle,
  Settings,
  Layers,
  UserPlus,
  Globe,
  Zap,
  CheckCircle2,
  Clock,
  Camera,
  ChevronDown,
  ChevronUp,
  Image as ImageIcon,
  ArrowUpRight,
  Copy,
  Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { apiFetch } from '../lib/api';
import socket from '../lib/socket';
import TokenTopupModal from './TokenTopupModal';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'lead_closed' | 'tokens_exhausted' | 'system';
  timestamp: Date;
  read: boolean;
}

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
  onLogout: () => void;
  userRole?: string | null;
  token?: string | null;
}

export default function Layout({ children, activeTab, onTabChange, onLogout, userRole: propUserRole, token }: LayoutProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const [isSidebarExpanded, setIsSidebarExpanded] = useState(true);
  const [showTokenTopup, setShowTokenTopup] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [newLeadsCount, setNewLeadsCount] = useState(0);
  const [unreadMessagesCount, setUnreadMessagesCount] = useState(0);
  const [expiredAdminsCount, setExpiredAdminsCount] = useState(0);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [isAnyModalOpen, setIsAnyModalOpen] = useState(false);
  const [isProfileExpanded, setIsProfileExpanded] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [copiedWhatsApp, setCopiedWhatsApp] = useState(false);
  const [userAvatar, setUserAvatar] = useState<string | null>(localStorage.getItem('user_avatar'));
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [displayName, setDisplayName] = useState(localStorage.getItem('user_display_name') || 'Najam Ali');

  useEffect(() => {
    const fetchProfile = async () => {
      if (!token) return;
      try {
        const stats = await apiFetch('/api/dashboard/stats');
        if (stats.avatar) {
          setUserAvatar(stats.avatar);
          localStorage.setItem('user_avatar', stats.avatar);
        }
        if (stats.displayName) {
          setDisplayName(stats.displayName);
          localStorage.setItem('user_display_name', stats.displayName);
        }
        if (stats.email) {
          localStorage.setItem('user_email', stats.email);
        }
      } catch (err) {
        console.error('Failed to fetch profile info:', err);
      }
    };
    fetchProfile();
  }, [token]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch('/api/user/profile', {
        method: 'PATCH',
        body: JSON.stringify({ displayName, avatar: userAvatar })
      });
      localStorage.setItem('user_display_name', displayName);
      setShowProfileModal(false);
    } catch (err) {
      console.error('Failed to update profile:', err);
      alert('Failed to update profile');
    }
  };

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 1024 * 1024) { // 1MB limit for firestore but if it's sql we can be a bit more lenient, usually 1mb is good for avatar
      alert('Image size should be less than 1MB');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64String = reader.result as string;
      setUserAvatar(base64String);
      localStorage.setItem('user_avatar', base64String);
      try {
        await apiFetch('/api/user/profile', {
          method: 'PATCH',
          body: JSON.stringify({ avatar: base64String })
        });
      } catch (err) {
        console.error('Failed to save avatar:', err);
      }
    };
    reader.readAsDataURL(file);
  };

  useEffect(() => {
    const handleExternalModal = (e: any) => {
      setIsAnyModalOpen(e.detail.isOpen);
    };
    window.addEventListener('toggle-modal-blur', handleExternalModal);
    return () => {
      window.removeEventListener('toggle-modal-blur', handleExternalModal);
    };
  }, []);

  useEffect(() => {
    const anyOpen = showLogoutConfirm || showNotifications || isMobileMenuOpen || isAnyModalOpen || showTokenTopup;
    document.body.style.overflow = anyOpen ? 'hidden' : 'unset';
    return () => { document.body.style.overflow = 'unset'; };
  }, [showLogoutConfirm, showNotifications, isMobileMenuOpen, isAnyModalOpen, showTokenTopup]);

  useEffect(() => {
    // Socket listeners for notifications
    socket.on('lead_closed', (data: any) => {
      const newNotif: Notification = {
        id: Math.random().toString(36).substr(2, 9),
        title: 'Lead Closed',
        message: `Lead ${data.name || 'Unknown'} has been marked as completed.`,
        type: 'lead_closed',
        timestamp: new Date(),
        read: false
      };
      setNotifications(prev => [newNotif, ...prev]);
    });

    socket.on('new_payment_request', () => {
      const notif: Notification = {
        id: Math.random().toString(36).substr(2, 9),
        title: 'New Payment Request',
        message: 'A user has submitted a payment request for token top-up.',
        type: 'system',
        timestamp: new Date(),
        read: false
      };
      setNotifications(prev => [notif, ...prev]);
    });

    socket.on('tokens_exhausted', () => {
      setShowTokenTopup(true);
      const newNotif: Notification = {
        id: Math.random().toString(36).substr(2, 9),
        title: 'Tokens Exhausted',
        message: 'Your token balance has reached zero. Systems are paused.',
        type: 'tokens_exhausted',
        timestamp: new Date(),
        read: false
      };
      setNotifications(prev => [newNotif, ...prev]);
    });

    return () => {
      socket.off('lead_closed');
      socket.off('tokens_exhausted');
    };
  }, []);

  useEffect(() => {
    const fetchStats = async () => {
      if (!token) return;
      try {
        const userRole = propUserRole || localStorage.getItem('user_role');
        
        if (userRole === 'super_admin') {
          const admins = await apiFetch('/api/super-admin/admins');
          const expired = admins.filter((a: any) => (a.tokens || 0) <= 0).length;
          setExpiredAdminsCount(expired);
        } else {
          const stats = await apiFetch('/api/leads/stats');
          setNewLeadsCount(stats.new_count || 0);
          
          const convStats = await apiFetch('/api/conversations/unread-count');
          setUnreadMessagesCount(convStats.total || 0);
        }
      } catch (error) {
        console.error('Failed to fetch stats:', error);
      }
    };

    fetchStats();
    const interval = setInterval(fetchStats, 30000); // Check every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const userRole = propUserRole || localStorage.getItem('user_role') || 'admin';

  const menuItems = userRole === 'super_admin' 
    ? [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'settings', label: 'API Settings', icon: Settings },
        { id: 'admins', label: 'Manage Users', icon: UserCircle, badge: expiredAdminsCount },
      ]
    : [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'conversations', label: 'Inbox', icon: MessageSquare, badge: unreadMessagesCount },
        { id: 'leads', label: 'Leads', icon: UserPlus, badge: newLeadsCount },
        { id: 'campaigns', label: 'Campaigns', icon: Send },
        { id: 'agents', label: 'Agents', icon: Users },
        { id: 'reports', label: 'Reports', icon: BarChart3 },
        { id: 'whatsapp', label: 'Channels', icon: Layers },
        { id: 'tracking', label: 'Tracking', icon: Globe },
        { id: 'settings', label: 'Settings', icon: Settings },
      ];

  const adminName = userRole === 'super_admin' 
    ? 'Najam Ali' 
    : (displayName || localStorage.getItem('user_display_name') || 'User');
  const userEmail = localStorage.getItem('user_email') || '';

  return (
    <div className="h-screen bg-white flex relative overflow-hidden">
      <div className="flex flex-1 h-full transition-all duration-300">
        {/* Background Decoration */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute -top-[20%] -right-[10%] w-[60%] h-[60%] bg-gray-900/3 rounded-full blur-[120px]" />
        <div className="absolute -bottom-[20%] -left-[10%] w-[60%] h-[60%] bg-gray-900/3 rounded-full blur-[120px]" />
      </div>

      <div className="flex flex-1 relative">
        {/* Desktop Sidebar */}
        <aside 
          className={`hidden md:flex flex-col ${isSidebarExpanded ? 'w-[280px]' : 'w-[80px]'} glass-card border-r border-gray-100 h-full sticky top-0 z-[110] transition-all duration-500 ease-[cubic-bezier(0.4,0,0.2,1)] relative overflow-hidden shrink-0 shadow-2xl shadow-gray-200/50`}
        >
          <div className="absolute top-0 left-0 w-full h-1 bg-gray-900" />
          
          <div className={`p-6 flex items-center ${isSidebarExpanded ? 'justify-between' : 'justify-center'}`}>
            <div className="flex items-center gap-4">
              <button 
                onClick={() => setIsSidebarExpanded(!isSidebarExpanded)}
                className="w-10 h-10 bg-gray-900 rounded-2xl flex items-center justify-center shadow-xl shadow-gray-900/20 rotate-[-5deg] hover:rotate-0 transition-all duration-500 shrink-0 cursor-pointer relative group/toggle"
              >
                <span className="text-white font-black text-xl italic group-hover/toggle:opacity-0 transition-opacity">WA</span>
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover/toggle:opacity-100 transition-opacity">
                  {isSidebarExpanded ? <PanelLeftClose className="w-6 h-6 text-white" /> : <PanelLeftOpen className="w-6 h-6 text-white" />}
                </div>
              </button>
              {isSidebarExpanded && (
                <motion.div
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex-1"
                >
                  <h1 className="text-xl font-black text-gray-900 tracking-tighter leading-none">
                    Handlingo
                  </h1>
                  <p className="text-[8px] font-black text-primary uppercase tracking-widest mt-1">Automate. Engage. Grow.</p>
                </motion.div>
              )}
            </div>
          </div>

        {userRole !== 'super_admin' && (
          <div className={`px-4 mb-8 ${isSidebarExpanded ? 'px-6' : 'px-4'}`}>
            <button
              onClick={() => {
                onTabChange('agents');
                if (!isSidebarExpanded) setIsSidebarExpanded(true);
              }}
              className={`group relative w-full bg-gray-900 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-2xl shadow-gray-900/20 transition-all active:scale-[0.98] overflow-hidden ${!isSidebarExpanded ? 'aspect-square p-0' : ''}`}
            >
              <div className="absolute inset-0 bg-primary translate-y-[100%] group-hover:translate-y-0 transition-transform duration-500" />
              {isSidebarExpanded && <span className="relative z-10">Create Agent</span>}
              {!isSidebarExpanded && <Plus className="w-4 h-4 relative z-10" />}
            </button>
          </div>
        )}

        <nav className="flex-1 px-3 space-y-4 overflow-y-auto overflow-x-hidden custom-scrollbar mt-4">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                onTabChange(item.id);
                if (!isSidebarExpanded) setIsSidebarExpanded(true);
              }}
              className={`w-full flex items-center ${isSidebarExpanded ? 'justify-between px-5' : 'justify-center'} py-4 rounded-2xl text-sm font-black uppercase tracking-widest transition-all relative group ${
                activeTab === item.id 
                  ? 'bg-gray-900 text-white shadow-xl shadow-gray-900/10 translate-x-2' 
                  : 'text-gray-400 hover:bg-white/50 hover:text-gray-900'
              }`}
            >
              <div className="flex items-center gap-4">
                <item.icon className={`w-5 h-5 transition-colors shrink-0 ${activeTab === item.id ? 'text-white' : 'text-gray-300'}`} />
                {isSidebarExpanded && <span>{item.label}</span>}
              </div>
              {item.badge !== undefined && item.badge > 0 && (
                <span className={`bg-primary text-white text-[10px] font-black px-2 py-0.5 rounded-full shadow-lg shadow-primary/20 ${!isSidebarExpanded ? 'absolute -top-1 -right-1' : ''}`}>
                  {item.badge}
                </span>
              )}
              {!isSidebarExpanded && (
                <div className="absolute left-full ml-4 px-3 py-2 bg-gray-900 text-white text-[10px] font-black uppercase tracking-widest rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none transition-all whitespace-nowrap z-[70]">
                  {item.label}
                </div>
              )}
            </button>
          ))}
        </nav>

        <div className="px-4 pb-2">
          <a 
            href="https://wa.link/2f15sw" 
            target="_blank" 
            rel="noopener noreferrer"
            className={`w-full flex items-center ${isSidebarExpanded ? 'justify-start px-5' : 'justify-center'} py-4 rounded-2xl text-sm font-black uppercase tracking-widest transition-all bg-[#E7FFDB] text-[#075E54] hover:bg-[#d8f9c1] shadow-lg shadow-green-500/10 border border-green-100 group relative`}
          >
            <div className="flex items-center gap-4">
              <MessageSquare className="w-5 h-5" />
              {isSidebarExpanded && <span>WhatsApp Help</span>}
            </div>
            {!isSidebarExpanded && (
              <div className="absolute left-full ml-4 px-3 py-2 bg-gray-900 text-white text-[10px] font-black uppercase tracking-widest rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none transition-all whitespace-nowrap z-[70]">
                WhatsApp Help
              </div>
            )}
          </a>
        </div>

        <div className="p-4 space-y-4">
          <div className={`glass-card rounded-[2rem] border border-gray-100/50 overflow-hidden transition-all duration-500`}>
            <div 
              onClick={() => {
                if (!isSidebarExpanded) {
                  setIsSidebarExpanded(true);
                }
                setIsProfileExpanded(!isProfileExpanded);
              }}
              className={`flex items-center cursor-pointer p-4 hover:bg-gray-50/50 transition-colors ${isSidebarExpanded ? 'justify-between' : 'justify-center'}`}
            >
              <div className="flex items-center gap-3">
                <div className="relative group/avatar">
                  <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center border border-white shadow-sm shrink-0 overflow-hidden">
                    {userAvatar ? (
                      <img src={userAvatar} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                      <UserCircle className="w-6 h-6 text-gray-400" />
                    )}
                  </div>
                </div>
                {isSidebarExpanded && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="min-w-0"
                  >
                    <p className="text-xs font-black text-gray-900 truncate">{adminName}</p>
                    <p className="text-[10px] font-bold text-gray-400 truncate">{userEmail || 'Active Session'}</p>
                  </motion.div>
                )}
              </div>
              {isSidebarExpanded && (
                <div className="text-gray-400">
                  {isProfileExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              )}
            </div>

            <AnimatePresence>
              {isProfileExpanded && isSidebarExpanded && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="px-4 pb-4 space-y-2 overflow-hidden"
                >
                  <button 
                    onClick={() => setShowProfileModal(true)}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest text-gray-600 hover:bg-gray-100 transition-all"
                  >
                    <UserCircle className="w-4 h-4 text-indigo-500" />
                    Profile
                  </button>
                  {userRole !== 'super_admin' && (
                    <button
                      onClick={() => { onTabChange('settings'); setIsProfileExpanded(false); }}
                      className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest text-gray-600 hover:bg-gray-100 transition-all"
                    >
                      <Settings className="w-4 h-4 text-gray-400" />
                      Billing & Settings
                    </button>
                  )}
                  <button 
                    onClick={() => setShowContactModal(true)}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest text-gray-600 hover:bg-gray-100 transition-all"
                  >
                    <Globe className="w-4 h-4 text-primary" />
                    Contact Support
                  </button>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowLogoutConfirm(true);
                    }} 
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest text-red-500 hover:bg-red-50 transition-all"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </aside>

      {/* Mobile Header - Removed for App Format */}

      <main className="flex-1 h-full overflow-y-auto overflow-x-hidden relative z-10 flex flex-col custom-scrollbar">
        {/* Top Header for Sidebar Toggle */}
        <header className="h-16 flex items-center px-4 md:px-8 border-b border-gray-100 bg-white/50 backdrop-blur-md sticky top-0 z-20">
          <button 
            onClick={() => setIsSidebarExpanded(!isSidebarExpanded)}
            className="p-2.5 bg-white border border-gray-100 text-gray-400 hover:text-primary rounded-xl shadow-sm transition-all active:scale-95"
            title={isSidebarExpanded ? "Collapse Sidebar" : "Expand Sidebar"}
          >
            {isSidebarExpanded ? <PanelLeftClose className="w-5 h-5" /> : <PanelLeftOpen className="w-5 h-5" />}
          </button>
          <div className="flex-1" />
        </header>

        <div className="flex-1 p-4 md:p-8">
          {children}
        </div>
        <footer className="px-4 md:px-8 py-3 border-t border-gray-100 flex items-center justify-center">
          <p className="text-[10px] text-gray-300 font-bold uppercase tracking-widest">
            Created by <span className="text-gray-400">Ondigix</span>
          </p>
        </footer>
      </main>
    </div>



    {/* User Touch Footer (Mobile Bottom Nav) - Removed for App Format */}
    </div>

    {/* Modals outside the blurred container */}
    <AnimatePresence>
      {isMobileMenuOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsMobileMenuOpen(false)}
            className="md:hidden fixed inset-0 bg-black/20 backdrop-blur-sm z-[90]"
          />
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="md:hidden fixed top-0 left-0 bottom-0 w-[280px] bg-white z-[100] shadow-2xl flex flex-col"
          >
            <div className="p-6 border-b border-gray-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-black text-sm italic">WA</span>
                </div>
                <h1 className="text-lg font-bold text-gray-900">Handlingo</h1>
              </div>
              <button onClick={() => setIsMobileMenuOpen(false)} className="text-gray-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4">
              <button
                onClick={() => {
                  onTabChange('agents');
                  setIsMobileMenuOpen(false);
                }}
                className="w-full bg-[#00C853] text-white py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#00C853]/20"
              >
                <Plus className="w-4 h-4" />
                Create Agent
              </button>
            </div>

            <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    onTabChange(item.id);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${
                    activeTab === item.id 
                      ? 'bg-[#F0F2F5] text-gray-900' 
                      : 'text-gray-500 hover:bg-gray-50'
                  }`}
                >
                  <item.icon className={`w-5 h-5 ${activeTab === item.id ? 'text-gray-900' : 'text-gray-400'}`} />
                  {item.label}
                </button>
              ))}
            </nav>

            <div className="p-6 border-t border-gray-100 space-y-4">
              <button 
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  setShowLogoutConfirm(true);
                }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-red-500 hover:bg-red-50 transition-all"
              >
                <LogOut className="w-5 h-5" />
                Logout
              </button>
            </div>
          </motion.div>
        </>
      )}

      {/* Profile Modal */}
    <AnimatePresence>
      {showProfileModal && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-md overflow-hidden border border-gray-100"
          >
            <div className="p-8">
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tighter">Edit Profile</h3>
                <button onClick={() => setShowProfileModal(false)} className="p-2 hover:bg-gray-100 rounded-xl transition-all">
                  <X className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              <div className="flex flex-col items-center mb-8">
                <div className="relative group">
                  <div className="w-24 h-24 rounded-3xl bg-gray-100 border-4 border-white shadow-xl overflow-hidden">
                    {userAvatar ? (
                      <img src={userAvatar} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                      <UserCircle className="w-full h-full text-gray-300 p-4" />
                    )}
                  </div>
                  <label className="absolute -bottom-2 -right-2 w-10 h-10 bg-primary text-white rounded-xl flex items-center justify-center shadow-lg cursor-pointer hover:scale-110 active:scale-95 transition-all">
                    <Camera className="w-5 h-5" />
                    <input type="file" className="hidden" accept="image/*" onChange={handleAvatarChange} />
                  </label>
                </div>
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mt-4">Profile Avatar</p>
                <p className="text-lg font-black text-gray-900 mt-2 uppercase tracking-tighter">{adminName}</p>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{userEmail}</p>
              </div>

              <div className="space-y-3">
                <button 
                  onClick={() => setShowProfileModal(false)}
                  className="w-full py-4 bg-gray-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-gray-800 transition-all shadow-xl shadow-gray-900/20"
                >
                  Close Profile
                </button>
                <div className="h-px bg-gray-100 my-4" />
                <button 
                  onClick={() => {
                    setShowProfileModal(false);
                    setShowLogoutConfirm(true);
                  }}
                  className="w-full py-4 bg-red-50 text-red-500 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-red-100 transition-all flex items-center justify-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>

    {/* Contact Modal */}
    <AnimatePresence>
      {showContactModal && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-md overflow-hidden border border-gray-100"
          >
            <div className="p-8">
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tighter">Contact Support</h3>
                <button onClick={() => setShowContactModal(false)} className="p-2 hover:bg-gray-100 rounded-xl transition-all">
                  <X className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              <div className="space-y-6">
                <div 
                  onClick={() => window.location.href = 'mailto:support@handlingo.com'}
                  className="bg-gray-50 p-6 rounded-3xl border border-gray-100 flex items-center justify-between group hover:bg-white transition-all cursor-pointer relative"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm text-indigo-500">
                      <BarChart3 className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-0.5">Email Support</p>
                      <p className="text-sm font-black text-gray-900">support@handlingo.com</p>
                    </div>
                  </div>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      navigator.clipboard.writeText('support@handlingo.com');
                      setCopiedEmail(true);
                      setTimeout(() => setCopiedEmail(false), 2000);
                    }}
                    className="p-2 text-gray-400 hover:text-indigo-600 transition-colors z-10"
                    title="Copy Email"
                  >
                    {copiedEmail ? <Check className="w-5 h-5 text-emerald-500" /> : <Copy className="w-5 h-5" />}
                  </button>
                </div>

                <div 
                  onClick={() => window.open('https://wa.link/tsmjxu', '_blank')}
                  className="bg-primary/5 p-6 rounded-3xl border border-primary/10 flex items-center justify-between group hover:bg-white transition-all cursor-pointer relative"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center shadow-lg shadow-primary/20 text-white">
                      <MessageSquare className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-primary/60 uppercase tracking-widest mb-0.5">WhatsApp Support</p>
                      <p className="text-sm font-black text-gray-900">+92 306 4443434</p>
                    </div>
                  </div>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      navigator.clipboard.writeText('+92 306 4443434');
                      setCopiedWhatsApp(true);
                      setTimeout(() => setCopiedWhatsApp(false), 2000);
                    }}
                    className="p-2 text-primary hover:text-primary-hover transition-colors z-10"
                    title="Copy Number"
                  >
                    {copiedWhatsApp ? <Check className="w-5 h-5 text-emerald-500" /> : <Copy className="w-5 h-5" />}
                  </button>
                </div>

                <div className="pt-4">
                  <button 
                    onClick={() => setShowContactModal(false)}
                    className="w-full py-4 bg-gray-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-gray-800 transition-all shadow-xl shadow-gray-900/20"
                  >
                    Done
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>

    {/* Token Topup Modal */}
    <TokenTopupModal 
      isOpen={showTokenTopup} 
      onClose={() => setShowTokenTopup(false)} 
    />

      {showLogoutConfirm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/20 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-md overflow-hidden border border-gray-100"
          >
            <div className="p-8">
              <div className="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center mb-6 mx-auto">
                <LogOut className="w-8 h-8 text-red-500" />
              </div>
              
              <h3 className="text-2xl font-black text-gray-900 text-center mb-4 uppercase tracking-tighter">
                Confirm Logout
              </h3>
              
              <p className="text-gray-500 text-center mb-8 font-medium leading-relaxed">
                Are you sure you want to logout? You will need to sign in again to access your account.
              </p>
              
              <div className="flex flex-col gap-3">
                <button
                  onClick={onLogout}
                  className="w-full py-4 bg-red-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-red-600 transition-all shadow-xl shadow-red-500/20"
                >
                  Yes, Logout
                </button>
                <button
                  onClick={() => setShowLogoutConfirm(false)}
                  className="w-full py-4 bg-gray-100 text-gray-700 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-gray-200 transition-all"
                >
                  Cancel
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
    </div>
  );
}