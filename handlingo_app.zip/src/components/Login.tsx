import React, { useState } from 'react';
import { Lock, User, Loader2, Eye, EyeOff, ShieldCheck, Mail, KeyRound } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface LoginProps {
  onLogin: (token: string) => void;
}

type Screen = 'login' | 'otp' | 'forgot';

export default function Login({ onLogin }: LoginProps) {
  const [screen, setScreen] = useState<Screen>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [otp, setOtp] = useState('');
  const [maskedEmail, setMaskedEmail] = useState('');
  const [forgotEmail, setForgotEmail] = useState('');
  const [resetOtp, setResetOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [resetStep, setResetStep] = useState<'email' | 'otp'>('email');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isBlocked, setIsBlocked] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) { setError('Username and password required'); return; }
    setIsLoading(true); setError('');
    try {
      const otpRes = await fetch('/api/auth/send-otp', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      const otpData = await otpRes.json();
      if (!otpRes.ok) {
        if (otpRes.status === 429) { setIsBlocked(true); }
        setError(otpData.error || 'Invalid credentials'); return;
      }
      if (otpData.required) { setMaskedEmail(otpData.maskedEmail); setScreen('otp'); return; }
      const res = await fetch('/api/auth/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (res.ok) {
        if (res.status === 429) { setIsBlocked(true); setError(data.error || 'Too many attempts'); return; }
        localStorage.setItem('user_role', data.role);
        localStorage.setItem('user_name', data.name || '');
        onLogin(data.token);
      } else { setError(data.error || 'Authentication failed'); }
    } catch { setError('Connection error'); }
    finally { setIsLoading(false); }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otp.trim()) { setError('Enter OTP'); return; }
    setIsLoading(true); setError('');
    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, otp }),
      });
      const data = await res.json();
      if (res.ok) {
        localStorage.setItem('user_role', data.role);
        localStorage.setItem('user_name', data.name || '');
        onLogin(data.token);
      } else { setError(data.error || 'Invalid OTP'); }
    } catch { setError('Connection error'); }
    finally { setIsLoading(false); }
  };

  const handleForgotSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail.trim()) { setError('Email required'); return; }
    setIsLoading(true); setError(''); setSuccess('');
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: forgotEmail }),
      });
      const data = await res.json();
      if (res.ok) { setSuccess(data.message); setResetStep('otp'); }
      else { setError(data.error || 'Failed to send OTP'); }
    } catch { setError('Connection error'); }
    finally { setIsLoading(false); }
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetOtp.trim() || !newPassword.trim()) { setError('All fields required'); return; }
    if (newPassword.length < 8) { setError('Password must be at least 8 characters'); return; }
    setIsLoading(true); setError('');
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: forgotEmail, otp: resetOtp, newPassword }),
      });
      const data = await res.json();
      if (res.ok) {
        setSuccess('Password reset! Please login.');
        setTimeout(() => goBack(), 2000);
      } else { setError(data.error || 'Reset failed'); }
    } catch { setError('Connection error'); }
    finally { setIsLoading(false); }
  };

  const goBack = () => {
    setScreen('login'); setError(''); setSuccess(''); setIsBlocked(false);
    setOtp(''); setForgotEmail(''); setResetOtp(''); setNewPassword(''); setResetStep('email');
  };

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white rounded-3xl shadow-2xl shadow-gray-200/60 p-8 border border-gray-100">

        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gray-900 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl shadow-gray-900/20">
            <span className="text-white font-black text-3xl italic">WA</span>
          </div>
          <h1 className="text-2xl font-black text-gray-900 uppercase tracking-tighter">Handlingo</h1>
          <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest mt-1">Automate. Engage. Grow.</p>
        </div>

        <AnimatePresence mode="wait">

          {screen === 'login' && (
            <motion.form key="login" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
                  <User className="w-3 h-3" /> Username
                </label>
                <input type="text"
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-gray-900/10 focus:border-gray-900 outline-none transition-all"
                  placeholder="admin@handlingo.com" value={username}
                  onChange={(e) => { setUsername(e.target.value); setError(''); setIsBlocked(false); }} />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
                  <Lock className="w-3 h-3" /> Password
                </label>
                <div className="relative">
                  <input type={showPassword ? 'text' : 'password'}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 pr-10 text-sm focus:ring-2 focus:ring-gray-900/10 focus:border-gray-900 outline-none transition-all"
                    placeholder="••••••••" value={password}
                    onChange={(e) => { setPassword(e.target.value); setError(''); }} />
                  <button type="button" onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              {error && <p className="text-red-500 text-xs font-medium text-center">{error}</p>}
              {isBlocked && (
                <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-center">
                  <p className="text-xs text-red-600 font-bold mb-2">Account temporarily locked (15 min)</p>
                  <button type="button" onClick={() => { setScreen('forgot'); setError(''); setIsBlocked(false); }}
                    className="text-xs text-gray-900 font-black underline">
                    Reset password to regain access
                  </button>
                </div>
              )}
              <button type="submit" disabled={isLoading || isBlocked}
                className="w-full py-4 bg-gray-900 text-white font-bold uppercase tracking-widest text-xs rounded-xl shadow-lg shadow-gray-900/20 hover:bg-gray-800 active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-50">
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Sign In'}
              </button>
              <button type="button" onClick={() => { setScreen('forgot'); setError(''); }}
                className="w-full text-center text-xs text-gray-400 hover:text-gray-700 mt-1 font-medium">
                Forgot Password?
              </button>
            </motion.form>
          )}

          {screen === 'otp' && (
            <motion.form key="otp" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onSubmit={handleVerifyOtp} className="space-y-4">
              <div className="text-center mb-4">
                <div className="w-14 h-14 bg-gray-900 rounded-2xl flex items-center justify-center mx-auto mb-3">
                  <ShieldCheck className="w-7 h-7 text-white" />
                </div>
                <h2 className="text-base font-black text-gray-900 uppercase tracking-tight">2-Step Verification</h2>
                <p className="text-xs text-gray-500 mt-1">OTP sent to <span className="font-bold text-gray-900">{maskedEmail}</span></p>
                <p className="text-xs text-gray-400">Valid for 10 minutes</p>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
                  <KeyRound className="w-3 h-3" /> Enter OTP
                </label>
                <input type="text" maxLength={6}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm text-center tracking-widest font-black focus:ring-2 focus:ring-gray-900/10 focus:border-gray-900 outline-none"
                  placeholder="000000" value={otp}
                  onChange={(e) => { setOtp(e.target.value.replace(/\D/g, '')); setError(''); }} />
              </div>
              {error && <p className="text-red-500 text-xs font-medium text-center">{error}</p>}
              <button type="submit" disabled={isLoading}
                className="w-full py-4 bg-gray-900 text-white font-bold uppercase tracking-widest text-xs rounded-xl shadow-lg shadow-gray-900/20 hover:bg-gray-800 active:scale-[0.98] transition-all flex items-center justify-center gap-2">
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Verify OTP'}
              </button>
              <button type="button" onClick={goBack}
                className="w-full text-center text-xs text-gray-400 hover:text-gray-600 mt-1">Back to Login</button>
            </motion.form>
          )}

          {screen === 'forgot' && (
            <motion.div key="forgot" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
              <div className="text-center mb-4">
                <div className="w-14 h-14 bg-gray-900 rounded-2xl flex items-center justify-center mx-auto mb-3">
                  <Mail className="w-7 h-7 text-white" />
                </div>
                <h2 className="text-base font-black text-gray-900 uppercase tracking-tight">Reset Password</h2>
                <p className="text-xs text-gray-500 mt-1">{resetStep === 'email' ? 'Enter your registered email' : 'Enter OTP + new password'}</p>
              </div>
              {resetStep === 'email' ? (
                <form onSubmit={handleForgotSend} className="space-y-4">
                  <input type="email"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-gray-900/10 focus:border-gray-900 outline-none"
                    placeholder="your@email.com" value={forgotEmail}
                    onChange={(e) => { setForgotEmail(e.target.value); setError(''); }} />
                  {error && <p className="text-red-500 text-xs font-medium text-center">{error}</p>}
                  {success && <p className="text-emerald-600 text-xs font-medium text-center">{success}</p>}
                  <button type="submit" disabled={isLoading}
                    className="w-full py-4 bg-gray-900 text-white font-bold uppercase tracking-widest text-xs rounded-xl hover:bg-gray-800 transition-all flex items-center justify-center gap-2">
                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Send OTP'}
                  </button>
                </form>
              ) : (
                <form onSubmit={handleReset} className="space-y-4">
                  <input type="text" maxLength={6}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm text-center tracking-widest font-black focus:ring-2 focus:ring-gray-900/10 focus:border-gray-900 outline-none"
                    placeholder="OTP Code" value={resetOtp}
                    onChange={(e) => { setResetOtp(e.target.value.replace(/\D/g, '')); setError(''); }} />
                  <input type="password"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-gray-900/10 focus:border-gray-900 outline-none"
                    placeholder="New Password (min 8 chars)" value={newPassword}
                    onChange={(e) => { setNewPassword(e.target.value); setError(''); }} />
                  {error && <p className="text-red-500 text-xs font-medium text-center">{error}</p>}
                  {success && <p className="text-emerald-600 text-xs font-medium text-center">{success}</p>}
                  <button type="submit" disabled={isLoading}
                    className="w-full py-4 bg-gray-900 text-white font-bold uppercase tracking-widest text-xs rounded-xl hover:bg-gray-800 transition-all flex items-center justify-center gap-2">
                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Reset Password'}
                  </button>
                </form>
              )}
              <button type="button" onClick={goBack}
                className="w-full text-center text-xs text-gray-400 hover:text-gray-600">Back to Login</button>
            </motion.div>
          )}

        </AnimatePresence>
      </motion.div>
    </div>
  );
}
